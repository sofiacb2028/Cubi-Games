## Card class

### Attribute
- suit : String (spades, hearts, clubs, diamonds)
- numRank : int (2-14 inclusive) : 2 is 2 and 14 is ace, use this to compare cards to find winner
- stringRank : String (could be "two", "queen") : String version of card's number rank for printing out
- hidden :boolean (true, false) : if card hidden status is true, instead of printing out the card it will just print "hidden"


### Constructor
+ Card (int player) : creates a card object with a random suit, number rank, string rank, and sets it's hidden status to true or false depending on if the argument "player" is 1 or 2

argument passed into parameter "player" should be 1 or 2, if 1 then create a card for the user that is NOT hidden, if 2 creates a card for the computer that starts out hidden
### Method
+ getRankInt() -> no parameter, returns an integer 2-14 inclusive (called in constructor)
+ getRankString (rankInt: int) -> one parameter: the integer rank of the card, returns the string version of that number rank
+ changeStatus(card: object) -> one parameter: a card object, changes hidden status of card to false, no return
+ toString() -> no parameter, returns [stringRank + "of" + [suit]] if object's hidden attribute is false and "hidden" if card's hidden attribute is true
+ getSuit() -> no parameter, returns a String: a random suit between spades, hearts, diamonds, or clubs
+ compareCards(playerCard: object, puterCard: object) -> 2 parameters: the 2 cards to compare, compares the two cards' numRanks and returns boolean "true" if player's card rank > computer's card rank, else returns false

Start with listing all the attributes (with data type and purpose).
Then list the constructor (with purpose, parameter if any)
Do the same for other methods: purpose, list of parameters and return value.
Also include the access modifier for all of them.
