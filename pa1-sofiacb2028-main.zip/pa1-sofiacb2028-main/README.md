# CS 212 Programming Assignment 1: Ace of Classes

## PROBLEM 
You are tasked to develop a card game. First, you need
to design a class representing poker cards and demonstrate its functionality. After that, you will develop the game using the class you design.



## PURPOSE OF THE ASSIGNMENT
The purpose of this assignment is for you to gain experience with:

1. designing your own class
2. practicing with constructor, setter and getter
3. using a random number generator method
4. working with multiple .java files
5. reinforcing control structures
5. using proper Java documentation


## REQUIREMENTS ANALYSIS
The first stage in your programming assignment is the requirements analysis stage.  You need to make sure you understand the below requirements for what needs to be included in your story’s decision making:

1. A card should include a suit: Spades (S), Hearts (H), Diamonds (D), Clubs (C), and a rank: 2-9, Ten (T), Jack (J), Queen (Q), King (K), Ace (A).
2. It should have a state i.e. face up or face down, and its state can be changed.
3. The class should have a default constructor that randomly creates am card.
4. The class should also have a compareTo() method to compare with another card (Ace is high, then K, Q, J, 10, ...., suit does not matter)
5. The class should have a `toString()` method that can help print out a card nicely if it is face up (i.e. `Ace of Spaces`, `Nine of Hearts`...), or `Hidden` if it is face down.
6. Any other methods you see fit.
7. A Driver/Tester/Main class with `main()` to demonstrate the functionality of your Card class.
   - Your main() is a card game similar to [War](https://en.wikipedia.org/wiki/War_(card_game)):
     - It is you (the player) vs. computer
     - Each round, a random card is dealt to the computer (face down) and the player (face up).
     - The player has a choice of skipping the round to start a new round (Only can skip 2 times)
     - If not skipped, all the cards will then be face up and whoever has a bigger card win a round (It can be a tie)
     - Whoever wins 5 rounds frist wins the game.
     
8. Handle invalid inputs gracefully (e.g., entering wrong options).

Sample run of the program:

```
Welcome to War!
--------------------------------
Score: Player 0 - 0 Computer
Round 1:
Computer: Hidden
Player: Ace of Spades
1. Skip (2 remaning), 2. Play 
2
Computer: Ten of Diamonds
Player: Ace of Spades
Player wins
--------------------------------
Score: Player 1 - 0 Computer
Round 2:
Computer: Hidden
Player: Three of Clubs
1. Skip (2 remaning), 2. Play 
1
--------------------------------
Score: Player 1 - 0 Computer
Round 3:
Computer: Hidden
Player: Six of Hearts
1. Skip (1 remaning), 2. Play 
2
Computer: Six of Spades
Player: Six of Hearts
Tie
--------------------------------
Score: Player 1 - 0 Computer
...
```

## DESIGN
The second stage is to design your solution based on the requirements:

1. The design should not include any code.

2. Write out your class design in DESIGN.MD  
    1. Start with listing all the attributes (with data type and purpose).  
    2. Then list the  constructor (with purpose, parameter if any)
    3. Do the same for other methods: purpose, list of parameters and return value.
    4. Also include the access modifier for all of them.
3. Draw a UML class diagram of your class, this should reflect what you have in your design.
4. Algorithm for the main() in **algorithm.txt**



### DESIGN SUBMISSION:

Submit to GitHub in PA1 repository: DESIGN.MD and a drawing of your class diagram.

Your diagram can be done by hand or the computer (I recommend [Drawio](https://www.drawio.com)), but must be submitted to GitHub in pdf or png format.

Algorithm for the main() in algorithm.txt

## PROGRAMMING REQUIREMENTS
After your design is complete and correct, it's time to start programming and then testing:

1. Fix design issues: If there were issues with your design, either not meeting requirements or in the format, fix that before you start writing your code.
2. Implementation: Write your program following the requirements and based on your design. Name your source code appropriately.  
    1. Follow good usability/HCI principles in your input and output (for instance, make it clear the type of input you are asking for).  
    2. Remember to state the purpose of the program.  
3. Testing: Make sure it works correctly; give it sample input, and check that the output is correct.  
  


## REFLECTION
Write a short reflection about the programming assignment in reflection.txt: on what you have learned. What is the most difficult part of the assignment? What could you have done differently?

## STYLE
You are expected to follow a consistent style. Pay particular attention to:

1. File headers: You should have a file header at the top of every file explaining the purpose and author of the file, describing input/output if any.
    It must start with (replace the bits in < >):  
    
    ```java
    /**
    * This is my code! It's goal is to <give purpose of file here>
    * CS 212 - Assignment <#>
    * @author <Your Name>
    * @version <a version number followed by a date>
    */
    ```
2. Variable names: use meaningful names in all camelCase style
3. Your code should have appropriate whitespace and avoid overly long line lengths.
4. Use clear documentation and careful formatting. Be consistent in indentation and alignment of braces.
5. Every method in your class must have a header comment of the form (replace the bits in < > and only use the number of `@param` that are needed for your method):  

    ```java
    /**
    * <A one sentence description of the method, ending with a period.>
    * <Optional longer description if desired>
    *
    * @param  <first parameter name>  <purpose of the parameter>
    * @param  <second parameter name>  <purpose of the second parameter>
    * @return      <what is returned>
    */
    ```
6. Your code should have no compilation errors.
7. Use of git: use meaningful commit messages and commit after reasonable milestones (i.e., a function has been completed)
    * A single commit for the whole project is not a good use of git


## FINAL SUBMISSION   
* To GitHub:
  * Your .java files with proper Javadoc
  * Your reflection. 
***Remember to double check on github.com that your files pushed. If they don't, you need to push them. I can only see what is on github.com, not what is only on your computer.***
