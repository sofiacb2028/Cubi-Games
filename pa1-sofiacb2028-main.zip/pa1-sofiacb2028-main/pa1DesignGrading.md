# PA1Design Grade
Grade: 29/30


**There is always a chance that I did not notice or comment on some small issues, or did not notice something due to other errors in the design. Make sure you've met all requirements after fixing your design.**


## Meets Requirements (21 points)

| Earned | Possible | Requirement                                                                 | Grading Comments |
|--------|----------|-----------------------------------------------------------------------------|------------------|
|   3     |     3     | Resonable rank attribute            |      just need 1               |
|     3   |     3     | Resonable suit attribute                             |                  |
|     3   |     3     | Resonable state attribute |                  |
|     3   |     3     | Has a default constructor                                 |                  |
|    3    |     3     | toString method            |                 |
|    3    |     3     | compare method            |                 |
|    2    |     3     | other method (i.e. flip method to flip the card )         |    changeStatus() i.e. flip just change the value of hidden, don't pass an object to it             |


## UML and algorithm (9 points)

| Earned | Possible | Requirement                          | Grading Comments |
|--------|----------|--------------------------------------|------------------|
|    2    |     2     | UML diagram reflects the design    |        |
|    2    |     2     | UML diagram has the correct format    |     static methods should be underlined             |
|    5    |     5     | Algorithm for the main is reasonable    |                  |


Additional Comments:
1. Not sure why you have getter methods here, you don't use them in your algorithm

