# PA 1 Final Grading
Grade: 70/70

# Updating Design (10 points)

| Earned | Possible | Requirement                                                                | Grading Comments |
|--------|----------|----------------------------------------------------------------------------|------------------|
|   5     |   5     | Update design to meet as suggested in design feedback                          |                |
|   5     |   5     | Update class diagram                          |                |


## Code Implementation (40 points)

| Earned | Possible | Requirement                                   | Grading Comments |
|--------|----------|-----------------------------------------------|------------------|
|   5     | 5       | Compile and run without error                          |                |
|3       | 3       | Each round, computer's card is face down, player's card faceup      |                  |
|2       | 2       | Player is asked to skip when they still can       |                  |
|3       | 3       | Enter a non-number input will not crash the game       |                  |
|2       | 2       | Bigger card wins the round, same ranks is a tie       |                  |
|3       | 3       | Score is kept correctly       |                  |
|2       | 2       | The game end when someone gets 5 points       |                  |
|4       | 4       | Card class has rank and suit           |                  |
|2       | 2       | Card class has an attribute to indicate the the card is face up or down           |                  |
|3       | 3       |Default constructor generates random rank and suit|  |
|3       | 3       |The compare method compare two cards return negative, 0 , positive for less than, equal to and greater than  |  |
|5       | 5       |toString() method return a good string to represent the card that is face up|  |
|2       | 2       |toString() method return a another string to indicate the card is face down|  |
|1       | 1       |toString() has Override notation on top|  |

## Code Readability (15 points)

| Earned | Possible | Requirement                                                | Grading Comments |
|--------|----------|------------------------------------------------------------|------------------|
|   2     | 2        | code follows readability guidelines (whitespace, comments) |                  |
|    2    | 2        | output follows good usability rules              |                  |
|    2    | 2        | each class has its own file              |                  |
|     2   | 2        | naming variable                                             |                  |
|      2  | 2        | intro comments                                             |            |
|      5  | 5        | Javadoc for class' methods                                             |            |



## Others (5 points)
| Earned | Possible | Requirement                                                | Grading Comments |
|--------|----------|------------------------------------------------------------|------------------|
|     3   |   3     | Repo has frequent commits and reasonable commit messages                  |                |
|     2   |   2     | No out .idea directories                  |                |

